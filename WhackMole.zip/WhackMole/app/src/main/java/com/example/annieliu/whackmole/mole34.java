package com.example.annieliu.whackmole;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class mole34 extends AppCompatActivity {

    ImageView[] moles = new ImageView[12];
    TextView scoreTextView;
    TextView timerTextView;
    int count = 0;
    int index;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_mole34);
        for(int i = 0; i < moles.length; i++){
            String id = "mole" + (i+1);

            int resID = getResources().getIdentifier(id, "id", getPackageName());
            moles[i] = findViewById(resID);
            moles[i].setVisibility(View.INVISIBLE);
        }
        scoreTextView = findViewById(R.id.score);
        timerTextView = findViewById(R.id.timer);
        final int rand1 = (int)(Math.random()*10+1);
        final int rand2 = (int)(Math.random()*10+1);
        final int rand3 = (int)(Math.random()*10+1);
        final int rand4 = (int)(Math.random()*10+1);
        new CountDownTimer(60000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                int seconds = (int) (millisUntilFinished / 1000);
                int minutes = seconds / 60;
                seconds = seconds % 60;
                timerTextView.setText(String.format(" %d:%02d", minutes, seconds));
                long currentTime = millisUntilFinished;
                if(currentTime%rand1==0 || currentTime%rand2==0 || currentTime%rand3==0){
                    moleUp();
                }
                if(currentTime%rand4==0 || currentTime%(rand4+1)==0){
                    moleDown();
                }

            }

            @Override
            public void onFinish() {
                createIntent();
            }
        }.start();
    }

    public void moleUp(){
        if(index==-1){
            index = (int)(Math.random()*moles.length);
            moles[index].setVisibility(View.VISIBLE);
        }
    }

    public void moleDown(){
        if(index!=-1){
            moles[index].setVisibility(View.INVISIBLE);
        }
        index = -1;
    }
    public void moleWhacked(View v){
        if(v.getVisibility()==View.VISIBLE){
            count++;
            scoreTextView.setText(String.format(" %d", count));
            v.setVisibility(View.INVISIBLE);
            index = -1;
        }
    }
    public void createIntent(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}